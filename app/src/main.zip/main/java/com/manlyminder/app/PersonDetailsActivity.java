package com.manlyminder.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.manlyminder.app.manager.PersonManager;
import com.manlyminder.app.model.Person;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class PersonDetailsActivity
        extends AppCompatActivity {

    public static final String EXTRA_POSITION =
            "position";

    private PersonManager manager;

    private List<Person> persons;

    private Person person;

    private int position;

    private TextView txtName;

    private TextView txtRelationship;

    private TextView txtLastContact;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {

        super.onCreate(
                savedInstanceState
        );

        setContentView(
                R.layout.activity_person_details
        );

        txtName =
                findViewById(
                        R.id.txtName
                );

        txtRelationship =
                findViewById(
                        R.id.txtRelationship
                );

        txtLastContact =
                findViewById(
                        R.id.txtLastContact
                );

        Button btnContactedToday =
                findViewById(
                        R.id.btnContactedToday
                );

        position =
                getIntent().getIntExtra(
                        EXTRA_POSITION,
                        -1
                );

        manager =
                new PersonManager(
                        this
                );

        persons =
                manager.getPersons();

        if (position < 0 ||
                position >= persons.size()) {

            finish();
            return;
        }

        person =
                persons.get(position);

        updateUi();

        btnContactedToday
                .setOnClickListener(v -> {

                    person.setLastContact(
                            System.currentTimeMillis()
                    );

                    manager.savePersons(
                            persons
                    );

                    updateUi();
                });
    }

    private void updateUi() {

        txtName.setText(
                person.getName()
        );

        txtRelationship.setText(
                person.getRelationship()
        );

        long days =
                TimeUnit.MILLISECONDS.toDays(
                        System.currentTimeMillis()
                                - person.getLastContact()
                );

        txtLastContact.setText(
                "Last contact: " +
                        days +
                        " days ago"
        );
    }
}