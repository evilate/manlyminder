package com.manlyminder.app.model;

public class Person {

    private String name;

    private String relationType;

    private long birthday;

    private long lastContact;

    private String notes;

    public Person() {
    }

    public Person(
            String name,
            String relationType,
            long birthday,
            long lastContact,
            String notes
    ) {

        this.name = name;
        this.relationType = relationType;
        this.birthday = birthday;
        this.lastContact = lastContact;
        this.notes = notes;
    }

    public String getName() {
        return name;
    }

    public void setName(
            String name
    ) {
        this.name = name;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(
            String relationType
    ) {
        this.relationType = relationType;
    }

    public long getBirthday() {
        return birthday;
    }

    public void setBirthday(
            long birthday
    ) {
        this.birthday = birthday;
    }

    public long getLastContact() {
        return lastContact;
    }

    public void setLastContact(
            long lastContact
    ) {
        this.lastContact = lastContact;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(
            String notes
    ) {
        this.notes = notes;
    }
}