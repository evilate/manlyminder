package com.manlyminder.app.fragment;


import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.manlyminder.app.R;
import com.manlyminder.app.adapter.PersonAdapter;
import com.manlyminder.app.manager.PersonManager;
import com.manlyminder.app.model.Person;

import android.content.Intent;
import android.widget.Spinner;

import com.manlyminder.app.PersonDetailsActivity;

import java.util.List;


public class PeopleFragment extends Fragment
        implements PersonAdapter.PersonListener {

    private PersonManager personManager;

    private List<Person> persons;

    private PersonAdapter adapter;

    public PeopleFragment() {
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState
    ) {

        View view =
                inflater.inflate(
                        R.layout.fragment_people,
                        container,
                        false
                );

        personManager =
                new PersonManager(
                        requireContext()
                );

        persons =
                personManager.getPersons();

        RecyclerView recyclerView =
                view.findViewById(
                        R.id.recyclerPeople
                );

        recyclerView.setLayoutManager(
                new LinearLayoutManager(
                        requireContext()
                )
        );

        adapter =
                new PersonAdapter(
                        persons,
                        this
                );

        recyclerView.setAdapter(
                adapter
        );

        FloatingActionButton fab =
                view.findViewById(
                        R.id.fabAddPerson
                );

        fab.setOnClickListener(v ->
                showAddPersonDialog()
        );

        return view;
    }

    private void showAddPersonDialog() {

        View dialogView =
                getLayoutInflater().inflate(
                        R.layout.dialog_person,
                        null
                );

        EditText editName =
                dialogView.findViewById(
                        R.id.editName
                );

        EditText editRelationship =
                dialogView.findViewById(
                        R.id.spinnerRelation
                );

        new AlertDialog.Builder(
                requireContext()
        )
                .setTitle("Add Person")
                .setView(dialogView)
                .setPositiveButton(
                        "Save",
                        (dialog, which) -> {

                            Person person =
                                    new Person(
                                            editName.getText().toString().trim(),
                                            editRelationship.getText().toString().trim(),
                                            0,
                                            System.currentTimeMillis(),
                                            ""
                                    );

                            persons.add(
                                    person
                            );

                            saveAndRefresh();
                        }
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void showEditPersonDialog(
            int position
    ) {

        Person person =
                persons.get(position);

        View dialogView =
                getLayoutInflater().inflate(
                        R.layout.dialog_person,
                        null
                );

        EditText editName =
                dialogView.findViewById(
                        R.id.editName
                );

        Spinner spinnerRelation =
                dialogView.findViewById(
                        R.id.spinnerRelation
                );

        editName.setText(
                person.getName()
        );

        editRelationship.setText(
                person.getRelationType()
        );

        new AlertDialog.Builder(
                requireContext()
        )
                .setTitle("Edit Person")
                .setView(dialogView)
                .setPositiveButton(
                        "Save",
                        (dialog, which) -> {

                            person.setName(
                                    editName.getText()
                                            .toString()
                                            .trim()
                            );

                            person.setRelationType(
                                    editRelationship.getText()
                                            .toString()
                                            .trim()
                            );

                            saveAndRefresh();
                        }
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void showDeleteDialog(
            int position
    ) {

        Person person =
                persons.get(position);

        new AlertDialog.Builder(
                requireContext()
        )
                .setTitle("Delete Person")
                .setMessage(
                        "Delete " +
                                person.getName() +
                                "?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {

                            persons.remove(
                                    position
                            );

                            saveAndRefresh();
                        }
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void saveAndRefresh() {

        personManager.savePersons(
                persons
        );

        adapter.refresh();
    }

    @Override
    public void onPersonClick(
            int position
    ) {

        Intent intent =
                new Intent(
                        requireContext(),
                        PersonDetailsActivity.class
                );

        intent.putExtra(
                PersonDetailsActivity.EXTRA_POSITION,
                position
        );

        startActivity(
                intent
        );
    }

    @Override
    public void onPersonLongClick(
            int position
    ) {

        showDeleteDialog(
                position
        );
    }
}