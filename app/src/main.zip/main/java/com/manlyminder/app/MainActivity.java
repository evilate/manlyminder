package com.manlyminder.app;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;

import androidx.appcompat.app.AppCompatActivity;

import com.manlyminder.app.fragment.EventsFragment;
import com.manlyminder.app.fragment.HomeFragment;
import com.manlyminder.app.fragment.PeopleFragment;
import com.manlyminder.app.fragment.SettingsFragment;
import com.manlyminder.app.manager.PersonManager;
import com.manlyminder.app.model.Person;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        BottomNavigationView bottomNav =
                findViewById(R.id.bottomNav);

        loadFragment(new HomeFragment());

        bottomNav.setOnItemSelectedListener(item -> {

            if (item.getItemId() == R.id.nav_home) {

                loadFragment(new HomeFragment());

            } else if (item.getItemId() == R.id.nav_people) {

                loadFragment(new PeopleFragment());

            } else if (item.getItemId() == R.id.nav_events) {

                loadFragment(new EventsFragment());

            } else if (item.getItemId() == R.id.nav_settings) {

                loadFragment(new SettingsFragment());
            }

            return true;
        });
    }

    private void loadFragment(Fragment fragment) {

        getSupportFragmentManager()
                .beginTransaction()
                .replace(
                        R.id.fragmentContainer,
                        fragment
                )
                .commit();
    }
}